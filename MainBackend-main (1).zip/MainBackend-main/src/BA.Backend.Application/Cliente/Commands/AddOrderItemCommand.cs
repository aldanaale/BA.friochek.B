using BA.Backend.Domain.Entities;
using BA.Backend.Domain.Repositories;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace BA.Backend.Application.Cliente.Commands;

public record AddOrderItemCommand(
    Guid OrderId,
    Guid ProductId,
    int Quantity,
    Guid TenantId) : IRequest<Unit>;

public class AddOrderItemCommandHandler(
    IOrderRepository orderRepository,
    ICoolerRepository coolerRepository,
    Microsoft.Extensions.Configuration.IConfiguration configuration)
    : IRequestHandler<AddOrderItemCommand, Unit>
{
    public async Task<Unit> Handle(AddOrderItemCommand request, CancellationToken ct)
    {
        var order = await orderRepository.GetByIdAsync(request.OrderId, request.TenantId, ct);
        if (order == null) throw new KeyNotFoundException("ORDER_NOT_FOUND");

        var cooler = await coolerRepository.GetByIdAsync(order.CoolerId, ct);
        if (cooler == null) throw new KeyNotFoundException("COOLER_NOT_FOUND");

        // Buscar producto en la BD para asegurar nombre y precio real
        var connStr = configuration.GetConnectionString("DefaultConnection");
        using var conn = new Microsoft.Data.SqlClient.SqlConnection(connStr);
        await conn.OpenAsync(ct);

        using var cmd = new Microsoft.Data.SqlClient.SqlCommand(
            "SELECT Name, Price FROM dbo.Products WHERE Id = @Id AND TenantId = @Tenant", conn);
        cmd.Parameters.AddWithValue("@Id", request.ProductId);
        cmd.Parameters.AddWithValue("@Tenant", request.TenantId);

        using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct))
            throw new KeyNotFoundException("PRODUCT_NOT_FOUND");

        var productName = reader.GetString(0);
        var unitPrice = reader.GetInt32(1);

        order.AddItem(request.ProductId, productName, request.Quantity, unitPrice, cooler.Capacity);

        await orderRepository.UpdateAsync(order, ct);
        await orderRepository.SaveChangesAsync(ct);

        return Unit.Value;
    }
}
