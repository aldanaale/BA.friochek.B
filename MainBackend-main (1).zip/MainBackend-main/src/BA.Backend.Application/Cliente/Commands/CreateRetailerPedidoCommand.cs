using BA.Backend.Application.Common.Interfaces;
using BA.Backend.Domain.Entities;
using BA.Backend.Domain.Repositories;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BA.Backend.Application.Cliente.Commands;

public record CreateRetailerPedidoCommand(
    Guid UserId,
    Guid TenantId,
    List<RetailerCoolerOrderEntry> Coolers
) : IRequest<string>;

public record RetailerCoolerOrderEntry(
    Guid CoolerId,
    List<RetailerOrderItemEntry> Items
);

public record RetailerOrderItemEntry(
    Guid ProductId,
    int Quantity
);

public class CreateRetailerPedidoHandler : IRequestHandler<CreateRetailerPedidoCommand, string>
{
    private readonly IOrderRepository _orderRepository;
    private readonly ICoolerRepository _coolerRepository;
    private readonly IProductRepository _productRepository;

    public CreateRetailerPedidoHandler(
        IOrderRepository orderRepository, 
        ICoolerRepository coolerRepository,
        IProductRepository productRepository)
    {
        _orderRepository = orderRepository;
        _coolerRepository = coolerRepository;
        _productRepository = productRepository;
    }

    public async Task<string> Handle(CreateRetailerPedidoCommand request, CancellationToken ct)
    {
        Guid lastOrderId = Guid.Empty;

        foreach (var coolerEntry in request.Coolers)
        {
            var cooler = await _coolerRepository.GetByIdWithTenantAsync(coolerEntry.CoolerId, request.TenantId, ct);
            if (cooler == null) continue;

            string tagId = "MANUAL-DASHBOARD";

            var order = Order.Create(request.TenantId, request.UserId, coolerEntry.CoolerId, tagId);

            foreach (var itemEntry in coolerEntry.Items)
            {
                var product = await _productRepository.GetByIdAsync(itemEntry.ProductId, ct);
                
                if (product != null && product.TenantId == request.TenantId)
                {
                    // En el dominio actual, AddItem pide coolerCapacity para validar
                    order.AddItem(product.Id, product.Name, itemEntry.Quantity, product.Price, cooler.Capacity);
                }
            }

            order.Confirm();
            await _orderRepository.AddAsync(order, ct);
            lastOrderId = order.Id;
        }

        await _orderRepository.SaveChangesAsync(ct);

        return lastOrderId.ToString();
    }
}
