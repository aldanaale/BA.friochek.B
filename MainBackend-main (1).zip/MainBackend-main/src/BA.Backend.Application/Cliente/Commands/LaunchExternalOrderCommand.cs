using BA.Backend.Application.Common.Interfaces;
using BA.Backend.Application.Cliente.DTOs;
using BA.Backend.Domain.Entities;
using BA.Backend.Domain.Repositories;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BA.Backend.Application.Cliente.Commands;

public record LaunchExternalOrderCommand(Guid ProductId, Guid UserId, Guid TenantId) : IRequest<ExternalOrderLaunchResult>;

public record ExternalOrderLaunchResult(string RedirectUrl, Guid OrderReferenceId);

public class LaunchExternalOrderCommandHandler : IRequestHandler<LaunchExternalOrderCommand, ExternalOrderLaunchResult>
{
    private readonly IProductRepository _productRepository;
    private readonly ITenantRepository _tenantRepository;
    private readonly IOrderRepository _orderRepository;
    private readonly IIntegrationFactory _integrationFactory;

    public LaunchExternalOrderCommandHandler(
        IProductRepository productRepository,
        ITenantRepository tenantRepository,
        IOrderRepository orderRepository,
        IIntegrationFactory integrationFactory)
    {
        _productRepository = productRepository;
        _tenantRepository = tenantRepository;
        _orderRepository = orderRepository;
        _integrationFactory = integrationFactory;
    }

    public async Task<ExternalOrderLaunchResult> Handle(LaunchExternalOrderCommand request, CancellationToken ct)
    {
        // 1. Obtener datos del Producto y del Tenant
        var product = await _productRepository.GetByIdAsync(request.ProductId, ct);
        if (product == null || product.TenantId != request.TenantId)
            throw new KeyNotFoundException("Producto no encontrado");

        var tenant = await _tenantRepository.GetActiveByIdAsync(request.TenantId, ct);
        if (tenant == null)
            throw new KeyNotFoundException("Tenant no encontrado");

        string sku = product.ExternalSku ?? "N/A";
        string? template = tenant.RedirectTemplate;
        
        // 2. Resolver URL mediante el Adaptador correspondiente
        var adapter = _integrationFactory.Create(tenant);
        var finalUrl = await adapter.GetRedirectUrlAsync(request.TenantId, request.UserId, sku, template, ct);

        // 3. Crear Referencia de Pedido Local (Orden Fantasma para Auditoría)
        var orderId = Guid.NewGuid();
        var reference = $"Pedido Externo: {product.Name} ({sku})";

        await _orderRepository.CreateExternalOrderReferenceAsync(orderId, request.TenantId, request.UserId, reference, ct);

        return new ExternalOrderLaunchResult(finalUrl, orderId);
    }
}
