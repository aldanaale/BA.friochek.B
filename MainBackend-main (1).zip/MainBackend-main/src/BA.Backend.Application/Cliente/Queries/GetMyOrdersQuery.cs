using BA.Backend.Application.Cliente.DTOs;
using BA.Backend.Application.Users.DTOs;
using BA.Backend.Domain.Repositories;
using MediatR;

namespace BA.Backend.Application.Cliente.Queries;

public record GetMyOrdersQuery(Guid UserId, Guid TenantId, int PageNumber = 1, int PageSize = 10)
    : IRequest<PagedResultDto<ClientOrderSummaryDto>>;

public class GetMyOrdersQueryHandler : IRequestHandler<GetMyOrdersQuery, PagedResultDto<ClientOrderSummaryDto>>
{
    private readonly IOrderRepository _orderRepository;

    public GetMyOrdersQueryHandler(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
    }

    public async Task<PagedResultDto<ClientOrderSummaryDto>> Handle(GetMyOrdersQuery request, CancellationToken ct)
    {
        var pageNumber = request.PageNumber <= 0 ? 1 : request.PageNumber;
        var pageSize = request.PageSize <= 0 ? 10 : request.PageSize;

        var (orders, totalCount) = await _orderRepository.GetPagedByUserIdAsync(request.UserId, request.TenantId, pageNumber, pageSize, ct);

        return new PagedResultDto<ClientOrderSummaryDto>
        {
            Items = orders.Select(o => new ClientOrderSummaryDto(
                o.Id,
                o.Status,
                o.Total,
                o.CreatedAt,
                o.DispatchDate
            )).ToList(),
            TotalCount = totalCount,
            PageNumber = pageNumber,
            PageSize = pageSize
        };
    }
}
