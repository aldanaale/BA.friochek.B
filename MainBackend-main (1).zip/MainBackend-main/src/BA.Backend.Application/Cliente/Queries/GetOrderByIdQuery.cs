using BA.Backend.Application.Cliente.DTOs;
using BA.Backend.Domain.Repositories;
using MediatR;

namespace BA.Backend.Application.Cliente.Queries;

public record GetOrderByIdQuery(Guid OrderId, Guid TenantId) : IRequest<ClientOrderDto?>;

public class GetOrderByIdQueryHandler : IRequestHandler<GetOrderByIdQuery, ClientOrderDto?>
{
    private readonly IOrderRepository _orderRepository;

    public GetOrderByIdQueryHandler(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
    }

    public async Task<ClientOrderDto?> Handle(GetOrderByIdQuery request, CancellationToken ct)
    {
        var order = await _orderRepository.GetByIdWithItemsAsync(request.OrderId, request.TenantId, ct);

        if (order == null) return null;

        return new ClientOrderDto(
            order.Id,
            order.Status,
            order.Total,
            order.CreatedAt,
            order.DispatchDate,
            order.Items.Select(i => new ClientOrderItemDto(
                i.Id,
                i.ProductId,
                i.ProductName,
                i.Quantity,
                i.UnitPrice,
                i.Subtotal
            )).ToList()
        );
    }
}
