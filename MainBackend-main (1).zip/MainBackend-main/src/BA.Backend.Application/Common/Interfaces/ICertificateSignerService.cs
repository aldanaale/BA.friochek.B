namespace BA.Backend.Application.Common.Interfaces;

public interface ICertificateSignerService
{
    string SignCertificate(Guid orderId, double latitude, double longitude, string ipAddress, string deviceFingerprint);
    bool VerifyCertificate(Guid orderId, double latitude, double longitude, string ipAddress, string deviceFingerprint, string hash);
}
