using System;
using System.Collections.Generic;

namespace BA.Backend.Application.EjecutivoComercial.DTOs;

public class EjecutivoDashboardDto
{
    public int ActiveClients { get; set; }
    public decimal MonthlySales { get; set; }
    public int PendingOrders { get; set; }
    public List<RecentSaleDto> RecentSales { get; set; } = new();
}

public class RecentSaleDto
{
    public Guid OrderId { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
}
