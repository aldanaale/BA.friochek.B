using MediatR;
using BA.Backend.Application.Common.Interfaces;
using BA.Backend.Domain.Repositories;
using BA.Backend.Domain.Exceptions;

namespace BA.Backend.Application.Transportista.Queries;

public record GetDeliveryCertificatePdfQuery(Guid CertificateId) : IRequest<byte[]>;

public class GetDeliveryCertificatePdfQueryHandler : IRequestHandler<GetDeliveryCertificatePdfQuery, byte[]>
{
    private readonly IOperationCertificateRepository _certificateRepository;
    private readonly IStoreRepository _storeRepository;
    private readonly IDeliveryRepository _deliveryRepository;
    private readonly ICoolerRepository _coolerRepository;
    private readonly IPdfReportService _pdfService;

    public GetDeliveryCertificatePdfQueryHandler(
        IOperationCertificateRepository certificateRepository,
        IStoreRepository storeRepository,
        IDeliveryRepository deliveryRepository,
        ICoolerRepository coolerRepository,
        IPdfReportService pdfService)
    {
        _certificateRepository = certificateRepository;
        _storeRepository = storeRepository;
        _deliveryRepository = deliveryRepository;
        _coolerRepository = coolerRepository;
        _pdfService = pdfService;
    }

    public async Task<byte[]> Handle(GetDeliveryCertificatePdfQuery request, CancellationToken cancellationToken)
    {
        var certificate = await _certificateRepository.GetByIdAsync(request.CertificateId, cancellationToken);
        
        if (certificate == null)
            throw new DomainException("CERTIFICATE_NOT_FOUND", "El certificado de operación no existe.");

        var order = await _deliveryRepository.GetOrderByIdAsync(certificate.OrderId, cancellationToken);
        if (order == null)
            throw new DomainException("ORDER_NOT_FOUND", "La orden asociada no existe.");

        var storeName = "Tienda Desconocida";

        var cooler = await _coolerRepository.GetByIdAsync(order.CoolerId, cancellationToken);
        if (cooler != null)
        {
            var store = await _storeRepository.GetByIdAsync(cooler.StoreId, cancellationToken);
            if (store != null)
                storeName = store.Name;
        }

        var pdfBytes = _pdfService.GenerateDeliveryCertificatePdf(
            certificate.Id,
            certificate.Tenant?.Name ?? "Tenant Desconocido",
            certificate.User?.FullName ?? "Transportista Desconocido",
            storeName,
            certificate.AcceptanceTimestamp,
            certificate.Latitude,
            certificate.Longitude,
            certificate.IpAddress,
            certificate.SignatureBase64,
            certificate.ServerHash
        );

        return pdfBytes;
    }
}
