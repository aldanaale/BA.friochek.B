using BA.Backend.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace BA.Backend.Domain.Repositories;

public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, Guid tenantId, CancellationToken ct = default);
    Task<IEnumerable<Order>> GetByUserIdAsync(Guid userId, Guid tenantId, CancellationToken ct = default);
    Task AddAsync(Order order, CancellationToken ct = default);
    Task<(IEnumerable<Order> Items, int TotalCount)> GetPagedByUserIdAsync(Guid userId, Guid tenantId, int pageNumber, int pageSize, CancellationToken ct);
    Task<Order?> GetByIdWithItemsAsync(Guid id, Guid tenantId, CancellationToken ct);
    Task CreateExternalOrderReferenceAsync(Guid id, Guid tenantId, Guid userId, string reference, CancellationToken ct);
    Task UpdateAsync(Order order, CancellationToken ct = default);
    Task DeleteAsync(Guid id, Guid tenantId, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}
