using BA.Backend.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BA.Backend.Infrastructure.Data.Configurations;

public class OrderItemConfiguration : IEntityTypeConfiguration<OrderItem>
{
    public void Configure(EntityTypeBuilder<OrderItem> builder)
    {
        builder.ToTable("OrderItems");
        builder.HasKey(e => e.Id);
        builder.Property(e => e.ProductName).IsRequired().HasMaxLength(500);
        // FIX: Subtotal es calculado (Quantity*UnitPrice), no existe como columna en BD
        builder.Ignore(e => e.Subtotal);
        builder.HasIndex(e => e.OrderId);
    }
}
