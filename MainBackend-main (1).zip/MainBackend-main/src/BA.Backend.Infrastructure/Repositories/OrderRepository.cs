using BA.Backend.Domain.Entities;
using BA.Backend.Domain.Repositories;
using BA.Backend.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BA.Backend.Infrastructure.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly ApplicationDbContext _context;

    public OrderRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<Order?> GetByIdAsync(Guid id, Guid tenantId, CancellationToken ct = default)
    {
        return await _context.Orders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.Id == id && o.TenantId == tenantId, ct);
    }

    public async Task<IEnumerable<Order>> GetByUserIdAsync(Guid userId, Guid tenantId, CancellationToken ct = default)
    {
        return await _context.Orders
            .Where(o => o.UserId == userId && o.TenantId == tenantId)
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync(ct);
    }

    public async Task AddAsync(Order order, CancellationToken ct = default)
    {
        await _context.Orders.AddAsync(order, ct);
    }

    public async Task UpdateAsync(Order order, CancellationToken ct = default)
    {
        _context.Orders.Update(order);
        await Task.CompletedTask;
    }

    public async Task DeleteAsync(Guid id, Guid tenantId, CancellationToken ct = default)
    {
        var order = await GetByIdAsync(id, tenantId, ct);
        if (order != null)
        {
            _context.Orders.Remove(order);
        }
    }

    public async Task<(IEnumerable<Order> Items, int TotalCount)> GetPagedByUserIdAsync(Guid userId, Guid tenantId, int pageNumber, int pageSize, CancellationToken ct)
    {
        var query = _context.Orders
            .Where(o => o.UserId == userId && o.TenantId == tenantId);

        var totalCount = await query.CountAsync(ct);
        var items = await query
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return (items, totalCount);
    }

    public async Task<Order?> GetByIdWithItemsAsync(Guid id, Guid tenantId, CancellationToken ct)
    {
        return await _context.Orders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.Id == id && o.TenantId == tenantId, ct);
    }

    public async Task CreateExternalOrderReferenceAsync(Guid id, Guid tenantId, Guid userId, string reference, CancellationToken ct)
    {
        // Usamos una consulta directa o un objeto sin navegación obligatoria para evitar errores de validación de CoolerId/NfcTagId
        // dado que es una "orden fantasma" de redirección externa.
        // Nota: InternalReference se omite si no existe en la tabla.
        var sql = @"
            INSERT INTO dbo.Orders (Id, TenantId, UserId, Status, CreatedAt, ExternalOrderId, CoolerId, NfcTagId)
            VALUES (@Id, @TenantId, @UserId, 'RedirigidoExterno', GETUTCDATE(), 'PENDIENTE_HUB', '00000000-0000-0000-0000-000000000000', 'EXTERNAL-REDIRECT')";
        
        await _context.Database.ExecuteSqlRawAsync(sql, new object[] { 
            new Microsoft.Data.SqlClient.SqlParameter("@Id", id),
            new Microsoft.Data.SqlClient.SqlParameter("@TenantId", tenantId),
            new Microsoft.Data.SqlClient.SqlParameter("@UserId", userId)
        }, ct);
    }

    public async Task SaveChangesAsync(CancellationToken ct = default)
    {
        await _context.SaveChangesAsync(ct);
    }
}
