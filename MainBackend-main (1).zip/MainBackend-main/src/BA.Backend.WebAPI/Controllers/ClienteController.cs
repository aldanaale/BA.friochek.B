using BA.Backend.Application.Cliente.DTOs;
using BA.Backend.Application.Cliente.Queries;
using BA.Backend.Application.Cliente.Commands;
using BA.Backend.Application.Users.DTOs;
using BA.Backend.Application.Common.DTOs;
using BA.Backend.Application.Common.Queries;
using BA.Backend.Domain.Exceptions;
using BA.Backend.WebAPI.DTOs.Cliente;
using BA.Backend.Application.Common.Interfaces;
using BA.Backend.Application.Common.Models;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BA.Backend.WebAPI.Controllers;

[ApiController]
[Route("cliente")]
[Authorize(Roles = "Cliente,Admin")]
[Tags("Cliente")]
public class ClienteController(
    IMediator mediator,
    ICurrentTenantService currentTenantService) : ControllerBase
{
    private Guid GetUserId() => Guid.Parse(currentTenantService.UserId ?? throw new UnauthorizedAccessException("Usuario no autenticado"));
    private Guid GetTenantId() => currentTenantService.TenantId ?? throw new UnauthorizedAccessException("Tenant no identificado");

    /// <summary>
    /// Dashboard Home - Retailer
    /// </summary>
    [HttpGet("home")]
    [ProducesResponseType(typeof(ApiResponse<RetailerHomeResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<RetailerHomeResponse>>> GetHome(CancellationToken ct)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var query = new GetRetailerDashboardQuery(userId, tenantId);
        var result = await mediator.Send(query, ct);

        return Ok(ApiResponse<RetailerHomeResponse>.SuccessResponse(result));
    }

    /// <summary>
    /// Crea un pedido desde el Dashboard (Múltiples coolers)
    /// </summary>
    [HttpPost("pedido")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> CreatePedido([FromBody] RetailerPedidoRequest req, CancellationToken ct)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var command = new CreateRetailerPedidoCommand(
            userId,
            tenantId,
            req.Coolers.Select(c => new RetailerCoolerOrderEntry(
                Guid.Parse(c.CoolerId),
                c.Items.Select(i => new RetailerOrderItemEntry(Guid.Parse(i.ProductId), i.Quantity)).ToList()
            )).ToList()
        );

        var requestId = await mediator.Send(command, ct);

        return Ok(ApiResponse<object>.SuccessResponse(new { requestId, status = "pending" }));
    }


    /// <summary>
    /// Catálogo de productos disponibles para el Tenant.
    /// </summary>
    /// <remarks>
    /// Ejemplo de Respuesta 200:
    /// {
    ///   "success": true,
    ///   "data": [
    ///     {
    ///       "id": "a1b2c3d4-0040-0000-0000-000000000000",
    ///       "name": "Helado Vainilla 1L",
    ///       "price": 2990.00,
    ///       "unit": "unidad",
    ///       "isActive": true
    ///     }
    ///   ],
    ///   "message": null
    /// }
    /// </remarks>
    [HttpGet("products")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ProductDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ProductDto>>>> GetProducts(CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var query = new GetProductsQuery(tenantId);
        var result = await mediator.Send(query, ct);
        return Ok(ApiResponse<IEnumerable<ProductDto>>.SuccessResponse(result));
    }

    /// <summary>
    /// Consulta el stock real de un producto en el sistema del Tenant.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet("products/{id:guid}/stock")]
    [ProducesResponseType(typeof(ApiResponse<int>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<int>>> GetProductStock(Guid id, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var query = new GetProductStockQuery(id, tenantId);
        var stock = await mediator.Send(query, ct);
        return Ok(ApiResponse<int>.SuccessResponse(stock));
    }

    /// <summary>
    /// Crea un nuevo pedido iniciado por NFC.
    /// </summary>
    /// <remarks>
    /// Ejemplo de Request:
    /// { "nfcAccessToken": "nfc_tok_eyJhbGciOiJIUzI1NiJ9.example" }
    /// 
    /// Ejemplo de Respuesta 200:
    /// {
    ///   "success": true,
    ///   "data": "a1b2c3d4-0030-0000-0000-000000000000",
    ///   "message": null
    /// }
    /// </remarks>
    [HttpPost("orders")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateOrder([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var command = new CreateOrderCommand(request.NfcAccessToken, userId, tenantId);
        var orderId = await mediator.Send(command, ct);

        return Ok(ApiResponse<Guid>.SuccessResponse(orderId));
    }

    /// <summary>
    /// Agrega un producto al pedido actual.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("orders/{id:guid}/items")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> AddItem(Guid id, [FromBody] AddItemRequest request, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var command = new AddOrderItemCommand(id, request.ProductId, request.Quantity, tenantId);
        await mediator.Send(command, ct);
        return Ok(ApiResponse<object>.SuccessResponse(null, "Item agregado exitosamente"));
    }

    /// <summary>
    /// LANZADOR OFICIAL: Redirige al portal externo del Tenant (Opción B - Deep Linking).
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("orders/external-launch")]
    [ProducesResponseType(typeof(ApiResponse<ExternalOrderLaunchResult>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ExternalOrderLaunchResult>>> LaunchExternalOrder([FromBody] ExternalLaunchRequest request, CancellationToken ct)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var command = new LaunchExternalOrderCommand(request.ProductId, userId, tenantId);
        var result = await mediator.Send(command, ct);

        return Ok(ApiResponse<ExternalOrderLaunchResult>.SuccessResponse(result));
    }

    public record ExternalLaunchRequest(Guid ProductId);

    /// <summary>
    /// Actualiza la cantidad de un item en la orden.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPut("orders/{id:guid}/items/{itemId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateItem(Guid id, Guid itemId, [FromBody] UpdateItemRequest request, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var command = new UpdateOrderItemCommand(id, itemId, request.Quantity, tenantId);
        await mediator.Send(command, ct);
        return Ok(ApiResponse<object>.SuccessResponse(null, "Item actualizado exitosamente"));
    }

    /// <summary>
    /// Elimina un ítem del pedido actual.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpDelete("orders/{id:guid}/items/{itemId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> RemoveItem(Guid id, Guid itemId, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var command = new RemoveOrderItemCommand(id, itemId, tenantId);
        await mediator.Send(command, ct);
        return Ok(ApiResponse<object>.SuccessResponse(null, "Item eliminado exitosamente"));
    }

    /// <summary>
    /// Confirma un pedido y devuelve el resumen final.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("orders/{id:guid}/confirm")]
    [ProducesResponseType(typeof(ApiResponse<ClientOrderSummaryDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ClientOrderSummaryDto>>> ConfirmOrder(Guid id, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var command = new ConfirmOrderCommand(id, tenantId);
        var summary = await mediator.Send(command, ct);
        return Ok(ApiResponse<ClientOrderSummaryDto>.SuccessResponse(summary));
    }

    /// <summary>
    /// Obtiene el listado paginado de pedidos del cliente autenticado.
    /// </summary>
    [HttpGet("orders")]
    [ProducesResponseType(typeof(ApiResponse<PagedResultDto<ClientOrderSummaryDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PagedResultDto<ClientOrderSummaryDto>>>> GetMyOrders([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var query = new GetMyOrdersQuery(userId, tenantId, pageNumber, pageSize);
        var result = await mediator.Send(query, ct);

        return Ok(ApiResponse<PagedResultDto<ClientOrderSummaryDto>>.SuccessResponse(result));
    }

    /// <summary>
    /// Obtiene el detalle de un pedido específico, incluyendo el desglose de sus ítems.
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet("orders/{id:guid}")]
    [ProducesResponseType(typeof(ApiResponse<ClientOrderDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<ClientOrderDto>>> GetOrderById(Guid id, CancellationToken ct)
    {
        var tenantId = GetTenantId();
        var query = new GetOrderByIdQuery(id, tenantId);
        var result = await mediator.Send(query, ct);

        if (result is null) return NotFound(ApiResponse<object>.FailureResponse("Pedido no encontrado"));

        return Ok(ApiResponse<ClientOrderDto>.SuccessResponse(result));
    }

    /// <summary>
    /// Crea una nueva solicitud de soporte técnico (Soporta Multipart/Form-Data para fotos).
    /// </summary>
    [HttpPost("tech-support")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateTechSupportForm([FromForm] CreateTechSupportRequest request, CancellationToken ct)
    {
        var result = await mediator.Send(new CreateTechSupportCommand(
            request.NfcAccessToken,
            request.FaultType,
            request.Description,
            request.ScheduledDate,
            request.Photos,
            GetUserId(),
            GetTenantId()
        ), ct);

        return Created("", ApiResponse<Guid>.SuccessResponse(result));
    }

    /// <summary>
    /// Crea una solicitud de soporte técnico (Soporta JSON, sin fotos).
    /// </summary>
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("tech-support-json")]
    [Consumes("application/json")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateTechSupportJson([FromBody] CreateTechSupportRequest request, CancellationToken ct)
    {
        var result = await mediator.Send(new CreateTechSupportCommand(
            request.NfcAccessToken,
            request.FaultType,
            request.Description,
            request.ScheduledDate,
            null,
            GetUserId(),
            GetTenantId()
        ), ct);

        return Created("", ApiResponse<Guid>.SuccessResponse(result));
    }

    /// <summary>
    /// Lista las solicitudes de soporte técnico del cliente
    /// </summary>
    [HttpGet("tech-support")]
    [ProducesResponseType(typeof(ApiResponse<PagedResultDto<TechSupportDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PagedResultDto<TechSupportDto>>>> GetMyTechRequests([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var query = new GetMyTechRequestsQuery(userId, tenantId, pageNumber, pageSize);
        var result = await mediator.Send(query, ct);
        return Ok(ApiResponse<PagedResultDto<TechSupportDto>>.SuccessResponse(result));
    }

    /// <summary>
    /// Reporta un tag NFC dañado que no se puede escanear.
    /// </summary>
    /// <remarks>
    /// Request:
    /// {
    ///   "coolerId": "a1b2c3d4-0020-0000-0000-000000000000",
    ///   "description": "El tag NFC está físicamente dañado, no responde al lector del celular"
    /// }
    /// </remarks>
    [HttpPost("nfc/report-damaged")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Guid>>> ReportDamagedTag([FromBody] ReportDamagedTagRequest request, CancellationToken ct)
    {
        var userId = GetUserId();
        var tenantId = GetTenantId();

        var command = new ReportDamagedTagCommand(request.CoolerId, request.Description, userId, tenantId);
        var id = await mediator.Send(command, ct);
        return Ok(ApiResponse<Guid>.SuccessResponse(id));
    }

}
