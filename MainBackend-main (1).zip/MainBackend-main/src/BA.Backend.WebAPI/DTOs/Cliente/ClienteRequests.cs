using Microsoft.AspNetCore.Http;

namespace BA.Backend.WebAPI.DTOs.Cliente;

public record CreateOrderRequest(string NfcAccessToken);

public record AddItemRequest(Guid ProductId, int Quantity);

public record UpdateItemRequest(int Quantity);

public record CreateTechSupportRequest(
    string NfcAccessToken, 
    string FaultType, 
    string Description, 
    DateTime ScheduledDate, 
    IFormFileCollection? Photos = null
);

public record ReportDamagedTagRequest(Guid CoolerId, string Description);

public record RetailerPedidoRequest(
    string UserId,
    List<CoolerPedidoItemRequest> Coolers
);

public record CoolerPedidoItemRequest(
    string CoolerId,
    List<PedidoProductItemRequest> Items
);

public record PedidoProductItemRequest(
    string ProductId,
    int Quantity
);
