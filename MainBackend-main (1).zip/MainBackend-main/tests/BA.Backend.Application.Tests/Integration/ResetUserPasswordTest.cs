using BA.Backend.Application.Common.Interfaces;
using BA.Backend.Domain.Entities;
using BA.Backend.Infrastructure.Data;
using BA.Backend.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using System.IO;
using System.Data.Common;

namespace BA.Backend.Application.Tests.Integration;

public class ResetUserPasswordTest
{
    [Fact(Skip = "Integration test - requires database with migrations applied")]
    [Trait("Category", "Integration")]
    public async Task ResetAdminPassword_ShouldUpdatePasswordHashInDatabase()
    {
        var config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var connectionString = config.GetConnectionString("DefaultConnection");

        if (string.IsNullOrEmpty(connectionString))
        {
            throw new InvalidOperationException("Connection string 'DefaultConnection' not found in appsettings.json");
        }

        if (!await DatabaseExistsAsync(connectionString))
        {
            throw new InvalidOperationException("Database does not exist. Run EF migrations first.");
        }

        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseSqlServer(connectionString)
            .Options;

        using (var context = new ApplicationDbContext(options, new TestCurrentTenantService()))
        {
            var user = await context.Users.IgnoreQueryFilters().FirstOrDefaultAsync(u => u.Email == "admin@test.com");
            
            if (user != null)
            {
            var mockLogger = new Mock<ILogger<Infrastructure.Services.PasswordHasher>>();
            var passwordHasher = new Infrastructure.Services.PasswordHasher(mockLogger.Object);
                user.PasswordHash = passwordHasher.Hash("Admin123!");
                
                context.Users.Update(user);
                await context.SaveChangesAsync();
                
                Assert.NotNull(user);
                Assert.Equal("admin@test.com", user.Email);
                Assert.True(passwordHasher.Verify("Admin123!", user.PasswordHash));
            }
            else
            {
                throw new InvalidOperationException("User 'admin@test.com' not found in database. Seed data may not be applied.");
            }
        }
    }

    private static async Task<bool> DatabaseExistsAsync(string connectionString)
    {
        try
        {
            using var connection = CreateConnection();
            connection.ConnectionString = connectionString;
            await connection.OpenAsync();
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static DbConnection CreateConnection() => new Microsoft.Data.SqlClient.SqlConnection();
}

public class TestCurrentTenantService : ICurrentTenantService
{
    public Guid? TenantId => Guid.Empty;
    public string? UserId => null;
    public string? Role => null;
    public bool IsPlatformAdmin => false;
}
